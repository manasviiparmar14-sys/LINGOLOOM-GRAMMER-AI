
import { Language, Mode, Topics } from './types';

export const getLangCode = (lang: Language): string => {
    switch (lang) {
      case 'English': return 'en-US';
      case 'Gujarati': return 'gu-IN';
      case 'Hindi': return 'hi-IN';
      case 'Sanskrit': return 'hi-IN'; // Fallback to Hindi for Sanskrit
      default: return 'en-US';
    }
};

export const LANGUAGES: Language[] = ['English', 'Gujarati', 'Hindi', 'Sanskrit'];
export const MODES: Mode[] = ['Explain', 'Practice', 'Correct', 'Quiz', 'Chat', 'Pronounce', 'Learning Path', 'Vocabulary SRS'];

export const TOPICS: Topics = {
  English: [
    { id: 'Adjective', name: 'Adjective' },
    { id: 'Adverb', name: 'Adverb' },
    { id: 'Alphabet', name: 'Alphabet' },
    { id: 'Antonyms', name: 'Antonyms' },
    { id: 'Articles', name: 'Articles' },
    { id: 'Capitalization', name: 'Capitalization' },
    { id: 'Clauses', name: 'Clauses' },
    { id: 'Compound and Complex Sentences', name: 'Compound and Complex Sentences' },
    { id: 'Composition Grammar', name: 'Composition Grammar' },
    { id: 'Conjunction', name: 'Conjunction' },
    { id: 'Degrees of Comparison', name: 'Degrees of Comparison' },
    { id: 'Determiners', name: 'Determiners' },
    { id: 'Error Correction', name: 'Error Correction' },
    { id: 'Figures of Speech', name: 'Figures of Speech' },
    { id: 'Gender', name: 'Gender' },
    { id: 'Gerunds and Infinitives', name: 'Gerunds and Infinitives' },
    { id: 'Homophones', name: 'Homophones' },
    { id: 'Infinitives', name: 'Infinitives' },
    { id: 'Interjection', name: 'Interjection' },
    { id: 'Modals', name: 'Modals' },
    { id: 'Narration (Direct/Indirect Speech)', name: 'Narration (Direct/Indirect Speech)' },
    { id: 'Noun', name: 'Noun' },
    { id: 'Number (Singular/Plural)', name: 'Number (Singular/Plural)' },
    { id: 'Parts of Speech', name: 'Parts of Speech' },
    { id: 'Phrases', name: 'Phrases' },
    { id: 'Prefix', name: 'Prefix' },
    { id: 'Preposition', name: 'Preposition' },
    { id: 'Pronoun', name: 'Pronoun' },
    { id: 'Punctuation', name: 'Punctuation' },
    { id: 'Question Tags', name: 'Question Tags' },
    { id: 'Reported Speech', name: 'Reported Speech' },
    { id: 'Sentence Types', name: 'Sentence Types' },
    { id: 'Spelling Rules', name: 'Spelling Rules' },
    { id: 'Subject and Predicate', name: 'Subject and Predicate' },
    { id: 'Subject-Verb Agreement', name: 'Subject-Verb Agreement' },
    { id: 'Suffix', name: 'Suffix' },
    { id: 'Synonyms', name: 'Synonyms' },
    { id: 'Tense', name: 'Tense' },
    { id: 'Transformation of Sentences', name: 'Transformation of Sentences' },
    { id: 'Verb', name: 'Verb' },
    { id: 'Voice (Active/Passive)', name: 'Voice (Active/Passive)' },
    { id: 'Word', name: 'Word' },
    { id: 'Word Formation', name: 'Word Formation' },
  ],
  Gujarati: [
    { id: 'અક્ષર', name: 'અક્ષર' },
    { id: 'અલંકાર', name: 'અલંકાર' },
    { id: 'અનુપ્રાસ', name: 'અનુપ્રાસ' },
    { id: 'અર્થપ્રકાર', name: 'અર્થપ્રકાર' },
    { id: 'અશુદ્ધિ સુધારવું', name: 'અશુદ્ધિ સુધારવું' },
    { id: 'અવ્યય', name: 'અવ્યય' },
    { id: 'ઋત્વિચાર', name: 'ઋત્વિચાર' },
    { id: 'એકારાંત શબ્દ', name: 'એકારાંત શબ્દ' },
    { id: 'એકવચન-બહુવચન', name: 'એકવચન-બહુવચન' },
    { id: 'ઉપસર્ગ', name: 'ઉપસર્ગ' },
    { id: 'ઉપવાક્ય', name: 'ઉપવાક્ય' },
    { id: 'કારક', name: 'કારક' },
    { id: 'કારકચિહ્ન', name: 'કારકચિહ્ન' },
    { id: 'છંદ', name: 'છંદ' },
    { id: 'જાતિવિચાર', name: 'જાતિવિચાર' },
    { id: 'તત્સમ તદ્ભવ', name: 'તત્સમ તદ્ભવ' },
    { id: 'ધ્વનિશ્રેણી', name: 'ધ્વનિશ્રેણી' },
    { id: 'નામપદ', name: 'નામપદ' },
    { id: 'પર્યાયવાચી શબ્દ', name: 'પર્યાયવાચી શબ્દ' },
    { id: 'પુલ્લિંગ-સ્ત્રીલિંગ', name: 'પુલ્લિંગ-સ્ત્રીલિંગ' },
    { id: 'પ્રત્યુત્તર', name: 'પ્રત્યુત્તર' },
    { id: 'પ્રત્યય', name: 'પ્રત્યય' },
    { id: 'પ્રત્યયરૂપ', name: 'પ્રત્યયરૂપ' },
    { id: 'પ્રયોગ', name: 'પ્રયોગ' },
    { id: 'પ્રયોગ વિદ્યા', name: 'પ્રયોગ વિદ્યા' },
    { id: 'બહુવચન', name: 'બહુવચન' },
    { id: 'રુક્તોક્તિ', name: 'રુક્તોક્તિ' },
    { id: 'રૂપાંતર', name: 'રૂપાંતર' },
    { id: 'લિંગ', name: 'લિંગ' },
    { id: 'લેખનકલાનું વ્યાકરણ', name: 'લેખનકલાનું વ્યાકરણ' },
    { id: 'લોકોક્તિ', name: 'લોકોક્તિ' },
    { id: 'વચન', name: 'વચન' },
    { id: 'વર્ણમાળા', name: 'વર્ણમાળા' },
    { id: 'વાક્ય', name: 'વાક્ય' },
    { id: 'વાક્યના પ્રકાર', name: 'વાક્યના પ્રકાર' },
    { id: 'વાક્યરચના', name: 'વાક્યરચના' },
    { id: 'વાક્યવિચાર', name: 'વાક્યવિચાર' },
    { id: 'વિભક્તિ', name: 'વિભક્તિ' },
    { id: 'વિરામચિહ્નો', name: 'વિરામચિહ્નો' },
    { id: 'વિરોધી શબ્દ', name: 'વિરોધી શબ્દ' },
    { id: 'વિશેષણ', name: 'વિશેષણ' },
    { id: 'વિશેષણભેદ', name: 'વિશેષણભેદ' },
    { id: 'શબ્દ', name: 'શબ્દ' },
    { id: 'શબ્દપ્રકાર', name: 'શબ્દપ્રકાર' },
    { id: 'શબ્દરચના', name: 'શબ્દરચના' },
    { id: 'શબ્દવિચાર', name: 'શબ્દવિચાર' },
    { id: 'શબ્દસંગ્રહ', name: 'શબ્દસંગ્રહ' },
    { id: 'શુદ્ધ અશુદ્ધ શબ્દ', name: 'શુદ્ધ અશુદ્ધ શબ્દ' },
    { id: 'સંગ્યા', name: 'સંગ્યા' },
    { id: 'સંધિ', name: 'સંધિ' },
    { id: 'સંધિભેદ', name: 'સંધિભેદ' },
    { id: 'સમાસ', name: 'સમાસ' },
    { id: 'સમાસભેદ', name: 'સમાસભેદ' },
    { id: 'સર્વનામ', name: 'સર્વનામ' },
    { id: 'સ્ત્રીલિંગ-પુલ્લિંગ', name: 'સ્ત્રીલિંગ-પુલ્લિંગ' },
  ],
  Hindi: [
    { id: 'अक्षर', name: 'अक्षर' },
    { id: 'अलंकार', name: 'अलंकार' },
    { id: 'अव्यय', name: 'अव्यय' },
    { id: 'अशुद्ध से शुद्ध', name: 'अशुद्ध से शुद्ध' },
    { id: 'अनुस्वार', name: 'अनुस्वार' },
    { id: 'उपसर्ग', name: 'उपसर्ग' },
    { id: 'ऋत्विचार', name: 'ऋत्विचार' },
    { id: 'एकवचन बहुवचन', name: 'एकवचन बहुवचन' },
    { id: 'ओर शब्द भेद', name: 'ओर शब्द भेद' },
    { id: 'कारक', name: 'कारक' },
    { id: 'काल', name: 'काल' },
    { id: 'कविता छंद', name: 'कविता छंद' },
    { id: 'क्रिया', name: 'क्रिया' },
    { id: 'क्रिया विशेषण', name: 'क्रिया विशेषण' },
    { id: 'छंद', name: 'छंद' },
    { id: 'जेंडर (लिंग)', name: 'जेंडर (लिंग)' },
    { id: 'टेंस', name: 'टेंस' },
    { id: 'दोष शुद्धि', name: 'दोष शुद्धि' },
    { id: 'धातु विचार', name: 'धातु विचार' },
    { id: 'निबंध लेखन', name: 'निबंध लेखन' },
    { id: 'पर्यायवाची शब्द', name: 'पर्यायवाची शब्द' },
    { id: 'प्रत्यय', name: 'प्रत्यय' },
    { id: 'प्रत्यय रूप', name: 'प्रत्यय रूप' },
    { id: 'प्रश्न वाक्य', name: 'प्रश्न वाक्य' },
    { id: 'बोल चाल', name: 'बोल चाल' },
    { id: 'भाषा और व्याकरण', name: 'भाषा और व्याकरण' },
    { id: 'मुहावरे', name: 'मुहावरे' },
    { id: 'रस', name: 'रस' },
    { id: 'लिंग परिवर्तन', name: 'लिंग परिवर्तन' },
    { id: 'लोकोक्तियाँ', name: 'लोकोक्तियाँ' },
    { id: 'वचन', name: 'वचन' },
    { id: 'वचन परिवर्तन', name: 'वचन परिवर्तन' },
    { id: 'वर्तनी', name: 'वर्तनी' },
    { id: 'वर्ण विचार', name: 'वर्ण विचार' },
    { id: 'वर्णमाला', name: 'वर्णमाला' },
    { id: 'वाक्य', name: 'वाक्य' },
    { id: 'वाक्य भेद', name: 'वाक्य भेद' },
    { id: 'वाक्य परिवर्तन', name: 'वाक्य परिवर्तन' },
    { id: 'वाक्य रचना', name: 'वाक्य रचना' },
    { id: 'वाक्य शुद्धि', name: 'वाक्य शुद्धि' },
    { id: 'वाच्य', name: 'वाच्य' },
    { id: 'वाच्य परिवर्तन', name: 'वाच्य परिवर्तन' },
    { id: 'वाच्य रूप', name: 'वाच्य रूप' },
    { id: 'विभक्ति', name: 'विभक्ति' },
    { id: 'विभक्ति विचार', name: 'विभक्ति विचार' },
    { id: 'विलोम शब्द', name: 'विलोम शब्द' },
    { id: 'विराम चिह्न', name: 'विराम चिह्न' },
    { id: 'विशेषण', name: 'विशेषण' },
    { id: 'संदेश लेखन', name: 'संदेश लेखन' },
    { id: 'संधि', name: 'संधि' },
    { id: 'संधि विच्छेद', name: 'संधि विच्छेद' },
    { id: 'संज्ञा', name: 'संज्ञा' },
    { id: 'सर्वनाम', name: 'सर्वनाम' },
    { id: 'समास', name: 'समास' },
    { id: 'समास विग्रह', name: 'समास विग्रह' },
  ],
  Sanskrit: [
    { id: 'अक्षर', name: 'अक्षर' },
    { id: 'अन्वय', name: 'अन्वय' },
    { id: 'अव्यय', name: 'अव्यय' },
    { id: 'उपसर्ग', name: 'उपसर्ग' },
    { id: 'उपसर्ग रूप', name: 'उपसर्ग रूप' },
    { id: 'कारक', name: 'कारक' },
    { id: 'काल', name: 'काल' },
    { id: 'काल परिवर्तन', name: 'काल परिवर्तन' },
    { id: 'कर्म', name: 'कर्म' },
    { id: 'क्रिया', name: 'क्रिया' },
    { id: 'गुरु लघु', name: 'गुरु लघु' },
    { id: 'चतुर्थी विभक्ति', name: 'चतुर्थी विभक्ति' },
    { id: 'तद्धित प्रत्यय', name: 'तद्धित प्रत्यय' },
    { id: 'धातु', name: 'धातु' },
    { id: 'धातुरूपाणि', name: 'धातुरूपाणि' },
    { id: 'धातु विचार', name: 'धातु विचार' },
    { id: 'निपात', name: 'निपात' },
    { id: 'पद', name: 'पद' },
    { id: 'पर्यायवाची', name: 'पर्यायवाची' },
    { id: 'पुरुष', name: 'पुरुष' },
    { id: 'प्रत्यय', name: 'प्रत्यय' },
    { id: 'प्रत्यय रूप', name: 'प्रत्यय रूप' },
    { id: 'बच्चन', name: 'बच्चन' },
    { id: 'लिंग', name: 'लिंग' },
    { id: 'लकार', name: 'लकार' },
    { id: 'वचन', name: 'वचन' },
    { id: 'वर्णमाला', name: 'वर्णमाला' },
    { id: 'वाच्य', name: 'वाच्य' },
    { id: 'वाच्य परिवर्तन', name: 'वाच्य परिवर्तन' },
    { id: 'विभक्ति', name: 'विभक्ति' },
    { id: 'विभक्ति प्रयोग', name: 'विभक्ति प्रयोग' },
    { id: 'विराम चिन्ह', name: 'विराम चिन्ह' },
    { id: 'विशेषण', name: 'विशेषण' },
    { id: 'शब्द', name: 'शब्द' },
    { id: 'शब्द विचार', name: 'शब्द विचार' },
    { id: 'शब्दरूपाणि', name: 'शब्दरूपाणि' },
    { id: 'शब्द संयोजन', name: 'शब्द संयोजन' },
    { id: 'शब्द संधि', name: 'शब्द संधि' },
    { id: 'संज्ञा', name: 'संज्ञा' },
    { id: 'संधि', name: 'संधि' },
    { id: 'संधि भेद', name: 'संधि भेद' },
    { id: 'संधि विच्छेद', name: 'संधि विच्छेद' },
    { id: 'समास', name: 'समास' },
    { id: 'समास भेद', name: 'समास भेद' },
    { id: 'समास विग्रह', name: 'समास विग्रह' },
    { id: 'सम्बोधन', name: 'सम्बोधन' },
    { id: 'सर्वनाम', name: 'सर्वनाम' },
  ],
};

export const getWelcomeMessage = (language: Language, type: 'full' | 'short' = 'full'): string => {
    const messages = {
        Gujarati: {
            full: 'ચાલો, આજે કંઈક નવું શીખીએ! કૃપા કરીને એક મોડ પસંદ કરો.',
            short: 'હું આરિયા! કૃપા કરીને મોડ પસંદ કરો.'
        },
        Hindi: {
            full: 'आइए, आज कुछ नया सीखें! कृपया एक मोड चुनें।',
            short: 'मैं आरिया! कृपया मोड चुनें।'
        },
        Sanskrit: {
            full: 'आगच्छन्तु, अद्य नूतनं किमपि पठामः! कृपया एकं मोड चिनोतु।',
            short: 'अहम् आरिया! कृपया मोड चिनोतु।'
        },
        English: {
            full: "Hello! Let's learn something new today! Please select a mode.",
            short: "I'm Aariya! Please select a mode."
        }
    };
    return messages[language][type];
};

export const getModeMessage = (language: Language, mode: Mode): string => {
    const messages = {
        Gujarati: {
            Explain: 'ચાલો વ્યાકરણ શીખીએ!',
            Practice: 'ચાલો પ્રેક્ટિસ કરીએ!',
            Correct: 'હું તમારા વાક્યો સુધારવામાં મદદ કરીશ.',
            Quiz: 'શું તમે ક્વિઝ માટે તૈયાર છો?',
            Chat: 'ચાલો વાત કરીએ!',
            Pronounce: 'ચાલો ઉચ્ચારણની પ્રેક્ટિસ કરીએ!',
            'Learning Path': 'હું તમારા માટે એક પ્લાન બનાવીશ.',
            'Vocabulary SRS': 'ચાલો તમારા શબ્દભંડોળને મજબૂત કરીએ!'
        },
        Hindi: {
            Explain: 'आइए व्याकरण सीखें!',
            Practice: 'आइए अभ्यास करें!',
            Correct: 'मैं आपके वाक्यों को सुधारने में मदद करूँगी।',
            Quiz: 'क्या आप क्विज़ के लिए तैयार हैं?',
            Chat: 'आइए बात करें!',
            Pronounce: 'आइए उच्चारण का अभ्यास करें!',
            'Learning Path': 'मैं आपके लिए एक प्लान बनाऊंगी।'
        },
        Sanskrit: {
            Explain: 'आगच्छन्तु व्याकरणं पठामः!',
            Practice: 'आगच्छन्तु अभ्यासं कुर्मः!',
            Correct: 'अहं भवतः वाक्यानि शुद्धीकर्तुं साहाय्यं करिष्यामि।',
            Quiz: 'किं भवान् प्रश्नोत्तरीं कृते सज्जः अस्ति?',
            Chat: 'आगच्छन्तु वार्तालापं कुर्मः!',
            Pronounce: 'आगच्छन्तु उच्चारणस्य अभ्यासं कुर्मः!',
            'Learning Path': 'अहं भवतः कृते एकं अध्ययन क्रम् निर्मास्यामि।'
        },
        English: {
            Explain: "Let's learn some grammar!",
            Practice: "Time to practice!",
            Correct: "I'll help you correct your sentences.",
            Quiz: "Ready for a quiz?",
            Chat: "Let's chat!",
            Pronounce: "Let's practice your pronunciation!",
            'Learning Path': "I'll create a learning plan for you.",
            'Vocabulary SRS': "Let's boost your vocabulary memory!"
        }
    };
    return messages[language][mode];
};

export const SYSTEM_INSTRUCTION = `
You are a multilingual, interactive language and grammar tutor AI named 'LingoLoom'.
Your job is to make grammar easy, enjoyable, and deeply understandable for school students (grades 1–12).
Your core objective is to explain grammar topics in simple, friendly, story-like language using creative examples and step-by-step reasoning. You must teach even the most difficult grammar rules in a way that feels fun and easy — like playing a learning game.

---
### Teaching Style & Rules:
1.  **Language:** Always use the student’s chosen 'Explanation Language' for the entire response. This is specified in the user's prompt as 'Language'.
2.  **Topic Context:** The user will select a 'Topic' from a specific language curriculum (e.g., 'સમાસ' from Gujarati). You must explain that specific topic.
3.  **Tone:** Speak like a friendly, encouraging teacher, not a textbook. Use a playful, easy, and engaging tone.
4.  **Simplicity:** Use simple, short sentences and real-life examples that children and teenagers can relate to.
5.  **Engagement:** Start with a small story, a relatable situation, or a funny trick whenever possible to capture the student's interest.
6.  **Structure for Difficult Topics:** Follow a step-by-step breakdown: Concept -> Rule -> Example -> Explanation.
7.  **Reasoning:** Always explain *why* a rule is used. The reasoning behind the grammar is as important as the rule itself.
8.  **Practice:** After teaching in 'Explain' mode, always provide 2–3 small practice questions with answers and clear reasoning.
9.  **Correction:** When correcting in 'Correct' mode, gently explain what was wrong and why, using easy-to-understand words.
10. **Encouragement:** Use positive and encouraging words like “સરસ પ્રયત્ન!”, “बहुत बढ़िया!”, “साधु!”, “Great job!”, etc., appropriate to the response language.
11. **Formatting:** Use bullets, numbered lists, emojis, and markdown for clarity (e.g., **bold** for headings, *italics* for emphasis).
12. **Closing:** Always end with a short, motivational note.

---
### Modes of Use (Based on user's 'Mode' input):

1.  **Explain Mode:**
    *   Teach the requested 'Topic' in detail.
    *   Use stories and creative examples.
    *   Follow the structured teaching style.
    *   Conclude with 2-3 practice questions with answers and reasoning.

2.  **Practice Mode:**
    *   Provide 3–5 short, practical examples related to the 'Topic' for the student to solve.
    *   After presenting the questions, provide the correct answers with detailed, step-by-step reasoning for each.

3.  **Correct Mode:**
    *   Analyze the 'Student Input' text for grammatical errors related to the 'Topic'.
    *   If there's an error, identify it, explain the mistake clearly, and provide the corrected version.
    *   Explain the relevant grammar rule that was broken.
    *   If the input is correct, praise the student and perhaps offer a slightly more advanced example.

4.  **Quiz Mode:**
    *   Create the requested number of fun, multiple-choice questions (MCQs) related to the 'Topic'.
    *   Adjust the complexity of the questions based on the requested 'Difficulty' (Easy, Medium, or Hard).
    *   Mandatory Output Format: You MUST output ONLY a JSON array of objects with the following structure:
        [{"question": "...", "options": ["...", "...", "...", "..."], "correctAnswer": "...", "explanation": "..."}]
    *   The 'correctAnswer' must match one of the 'options' exactly.
    *   The questions, options and explanations MUST be in the 'Explanation Language'.
    *   Do not include any other text besides the JSON array.

5.  **Pronounce Mode:**
    *   You will be given a 'Target Sentence' and a 'User Spoken' text (this is what the machine heard the user say).
    *   Compare the two. Identify which words the user mispronounced or missed entirely.
    *   Explain the correct pronunciation in a friendly way using the Explanation Language.
    *   If they matched perfectly, praise them highly!

6.  **Learning Path Mode:**
    *   You will be given a 'Proficiency Level' (Beginner, Intermediate, Advanced) and a 'Topic' (or just general language).
    *   Generate a personalized, structured lesson plan for the chosen language.
    *   Include topics to cover, short exercises, quizzes, and review strategies.
    *   Use markdown tables, bold text, and lists to make the plan beautiful and easy to read.
7.  **Vocabulary SRS Mode:**
    *   You will be asked to generate a list of 10 new vocabulary words for the chosen language and proficiency level.
    *   For each word, provide the word, its meaning in the 'Explanation Language', and a simple example sentence.
    *   Format as a list of JSON objects (within a code block) so the system can parse it: [{"word": "...", "translation": "...", "example": "..."}].
---
### Input Format from User (You will receive this):
Language: [This is the language for your RESPONSE]
Mode: (Explain / Practice / Correct / Quiz / Pronounce / Learning Path / Vocabulary SRS)
Topic: [The topic name] (from [Original Topic Language] grammar)
Difficulty: (Easy / Medium / Hard - only if Mode is Quiz)
Proficiency: (Beginner / Intermediate / Advanced - only if Mode is Learning Path)
Student Input: (Target text or input text)
Spoken Input: (Recognized audio text - only if Mode is Pronounce)

---
### Output Format (Your response should follow this):
-   Start with a cheerful greeting in the chosen response language (e.g., “ચાલો, આજે રસપ્રદ રીતે શીખીએ!”, “आइए, आज कुछ नया सीखें!”).
-   Present the content according to the requested 'Mode' and 'Topic'.
-   Use clear headings, bullets, or numbered steps.
-   Ensure all examples and practice questions come with answers and reasoning.
-   Maintain your friendly, teacher-like persona throughout.
-   End with a short, positive, and motivational sentence.
`;
