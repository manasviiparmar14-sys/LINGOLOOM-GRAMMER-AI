
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Language, Mode, Topic, Difficulty } from './types';
import { LANGUAGES, MODES, TOPICS, getWelcomeMessage, getModeMessage } from './constants';
import { runTutorQueryStream, runFollowUpQueryStream, runChatQueryStream } from './services/geminiService';
import { BookIcon, BrainCircuitIcon, EditIcon, QuizIcon, SparklesIcon, SunIcon, MoonIcon, SendIcon, LgaLogoIcon, MessageCircleIcon, MicIcon, MapIcon } from './components/icons';
import Loader from './components/Loader';
import ResultDisplay from './components/ResultDisplay';
import Character from './components/Character';
import SrsDeck from './components/SrsDeck';
import QuizComponent from './components/QuizComponent';
import { SRSItem, QuizQuestion } from './types';

const getInitialTheme = (): 'light' | 'dark' => {
    if (typeof window === 'undefined') return 'light';
    const savedTheme = window.localStorage.getItem('theme');
    if (savedTheme === 'dark' || savedTheme === 'light') {
        return savedTheme;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};


const App: React.FC = () => {
    const [language, setLanguage] = useState<Language>('English');
    const [explanationLanguage, setExplanationLanguage] = useState<Language>('English');
    const [mode, setMode] = useState<Mode>('Explain');
    const [difficulty, setDifficulty] = useState<Difficulty>('Easy');
    const [proficiency, setProficiency] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Beginner');
    const [topic, setTopic] = useState<string>(TOPICS['English'][0].id);
    const [studentInput, setStudentInput] = useState<string>('');
    const [recognizedText, setRecognizedText] = useState<string>('');
    const [isRecording, setIsRecording] = useState<boolean>(false);
    const [result, setResult] = useState<string>('');
    const recognitionRef = useRef<any>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const [theme, setTheme] = useState<'light' | 'dark'>(getInitialTheme());
    const [followUpInput, setFollowUpInput] = useState<string>('');
    const [lastQuery, setLastQuery] = useState<{ language: Language, explanationLanguage: Language, mode: Mode, topic: string, studentInput: string } | null>(null);
    const [characterMessage, setCharacterMessage] = useState<string>('');
    const [infoModal, setInfoModal] = useState<{title: string, content: React.ReactNode} | null>(null);
    const [srsItems, setSrsItems] = useState<SRSItem[]>(() => {
        const saved = localStorage.getItem('srs_items');
        return saved ? JSON.parse(saved) : [];
    });
    const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
    const [quizQuestionCount, setQuizQuestionCount] = useState<number>(10);
    const [isQuizActive, setIsQuizActive] = useState<boolean>(false);
    const followUpInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        localStorage.setItem('srs_items', JSON.stringify(srsItems));
    }, [srsItems]);

    const handleSrsUpdate = (updatedItems: SRSItem[]) => {
        setSrsItems(updatedItems);
    };

    const handleGenerateSrsItems = async () => {
        setIsLoading(true);
        setCharacterMessage("Let me find some good words for you... 📚");
        try {
            const stream = await runTutorQueryStream(language, explanationLanguage, 'Vocabulary SRS', '', '', 'Medium', proficiency, '');
            let fullText = "";
            for await (const chunk of stream) {
                fullText += chunk.text || '';
            }
            
            // Extract JSON from the response
            const jsonMatch = fullText.match(/\[\s*\{.*\}\s*\]/s);
            if (jsonMatch) {
                const newWords = JSON.parse(jsonMatch[0]);
                const newSrsItems: SRSItem[] = newWords.map((w: any) => ({
                    id: Math.random().toString(36).substr(2, 9),
                    word: w.word,
                    translation: w.translation,
                    language: language,
                    level: 0,
                    lastSeen: 0,
                    nextReview: Date.now()
                }));
                setSrsItems([...srsItems, ...newSrsItems]);
                setCharacterMessage("I've added 10 new words to your deck! 🌟");
            } else {
                throw new Error("Could not parse vocabulary list");
            }
        } catch (e) {
            console.error(e);
            setError("Failed to generate words. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    const languageColorClasses = {
        English: {
            active: 'bg-blue-600 text-white focus:ring-blue-500',
            inactive: 'hover:bg-blue-100 dark:hover:bg-blue-900/50 focus:ring-blue-500'
        },
        Gujarati: {
            active: 'bg-orange-500 text-white focus:ring-orange-500',
            inactive: 'hover:bg-orange-100 dark:hover:bg-orange-900/50 focus:ring-orange-500'
        },
        Hindi: {
            active: 'bg-red-500 text-white focus:ring-red-500',
            inactive: 'hover:bg-red-100 dark:hover:bg-red-900/50 focus:ring-red-500'
        },
        Sanskrit: {
            active: 'bg-yellow-400 text-black focus:ring-yellow-500',
            inactive: 'hover:bg-yellow-100 dark:hover:bg-yellow-900/50 focus:ring-yellow-500'
        }
    };

    const modeColorClasses = {
        Explain: {
            active: 'bg-green-500 text-white focus:ring-green-500',
            inactive: 'hover:bg-green-100 dark:hover:bg-green-900/50 focus:ring-green-500'
        },
        Practice: {
            active: 'bg-yellow-500 text-black focus:ring-yellow-500',
            inactive: 'hover:bg-yellow-100 dark:hover:bg-yellow-900/50 focus:ring-yellow-500'
        },
        Correct: {
            active: 'bg-red-500 text-white focus:ring-red-500',
            inactive: 'hover:bg-red-100 dark:hover:bg-red-900/50 focus:ring-red-500'
        },
        Quiz: {
            active: 'bg-blue-500 text-white focus:ring-blue-500',
            inactive: 'hover:bg-blue-100 dark:hover:bg-blue-900/50 focus:ring-blue-500'
        },
        Chat: {
            active: 'bg-purple-500 text-white focus:ring-purple-500',
            inactive: 'hover:bg-purple-100 dark:hover:bg-purple-900/50 focus:ring-purple-500'
        },
        Pronounce: {
            active: 'bg-pink-500 text-white focus:ring-pink-500',
            inactive: 'hover:bg-pink-100 dark:hover:bg-pink-900/50 focus:ring-pink-500'
        },
        'Learning Path': {
            active: 'bg-indigo-500 text-white focus:ring-indigo-500',
            inactive: 'hover:bg-indigo-100 dark:hover:bg-indigo-900/50 focus:ring-indigo-500'
        },
        'Vocabulary SRS': {
            active: 'bg-rose-500 text-white focus:ring-rose-500',
            inactive: 'hover:bg-rose-100 dark:hover:bg-rose-900/50 focus:ring-rose-500'
        }
    };

    useEffect(() => {
        if (theme === 'dark') {
            document.documentElement.classList.add('dark');
            localStorage.setItem('theme', 'dark');
        } else {
            document.documentElement.classList.remove('dark');
            localStorage.setItem('theme', 'light');
        }
    }, [theme]);

    const toggleTheme = () => {
        setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
    };

    useEffect(() => {
        setExplanationLanguage(language); // Sync explanation language when topic language changes
        setTopic(TOPICS[language][0].id);
        setResult('');
        setError(null);
        setFollowUpInput('');
        setLastQuery(null);
        setCharacterMessage(getWelcomeMessage(language, 'short'));
    }, [language]);

    useEffect(() => {
        setResult('');
        setError(null);
        setFollowUpInput('');
        setLastQuery(null);
        setIsQuizActive(false);
        setQuizQuestions([]);
        setCharacterMessage(getModeMessage(language, mode));
    }, [mode]);

    const getModeIcon = (modeName: Mode) => {
        switch (modeName) {
            case 'Explain': return <BookIcon className="w-5 h-5 mr-2" />;
            case 'Practice': return <BrainCircuitIcon className="w-5 h-5 mr-2" />;
            case 'Correct': return <EditIcon className="w-5 h-5 mr-2" />;
            case 'Quiz': return <QuizIcon className="w-5 h-5 mr-2" />;
            case 'Chat': return <MessageCircleIcon className="w-5 h-5 mr-2" />;
            case 'Pronounce': return <MicIcon className="w-5 h-5 mr-2" />;
            case 'Learning Path': return <MapIcon className="w-5 h-5 mr-2" />;
            case 'Vocabulary SRS': return <BrainCircuitIcon className="w-5 h-5 mr-2" />;
            default: return null;
        }
    };

    const startRecording = () => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            setError("Speech recognition is not supported in this browser.");
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.lang = language === 'English' ? 'en-US' : language === 'Gujarati' ? 'gu-IN' : 'hi-IN';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.onstart = () => setIsRecording(true);
        recognition.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript;
            setRecognizedText(transcript);
            setIsRecording(false);
        };
        recognition.onerror = (event: any) => {
            console.error("Speech recognition error", event.error);
            setError("Speech recognition failed. Please try again.");
            setIsRecording(false);
        };
        recognition.onend = () => setIsRecording(false);

        recognitionRef.current = recognition;
        recognition.start();
    };

    const handleSubmit = useCallback(async () => {
        if (mode === 'Chat') {
            if (!studentInput.trim()) {
                setError('Please enter a message to chat.');
                return;
            }
        } else if (mode === 'Pronounce') {
            if (!studentInput.trim() || !recognizedText.trim()) {
                setError('Please provide a target sentence and record your voice.');
                return;
            }
        } else if (mode === 'Learning Path') {
            // no specific topic needed, just proficiency and language are enough
        } else {
            if (!topic) {
                setError('Please select a topic.');
                return;
            }
            if (mode === 'Correct' && !studentInput.trim()) {
                setError('Please provide text to correct.');
                return;
            }
        }

        setIsLoading(true);
        setResult('');
        setError(null);
        setFollowUpInput('');
        setCharacterMessage('Let me think... 🤔');
        
        const currentQuery = { language, explanationLanguage, mode, topic, studentInput, difficulty };
        setLastQuery(currentQuery);

        try {
            if (mode === 'Chat') {
                const stream = await runChatQueryStream(studentInput);
                let currentResult = "";
                for await (const chunk of stream) {
                    currentResult += chunk.text || '';
                    setResult(currentResult);
                }
                setCharacterMessage('Here you go! ✨ Ask me a follow-up if you need to!');
            } else if (mode === 'Quiz') {
                const stream = await runTutorQueryStream(language, explanationLanguage, mode, topic, `${quizQuestionCount} questions`, difficulty, proficiency, '');
                let fullText = "";
                for await (const chunk of stream) {
                    fullText += chunk.text || '';
                }
                
                const jsonMatch = fullText.match(/\[\s*\{.*\}\s*\]/s);
                if (jsonMatch) {
                    const parsedQuestions = JSON.parse(jsonMatch[0]);
                    setQuizQuestions(parsedQuestions);
                    setIsQuizActive(true);
                    setCharacterMessage("Let's test your skills! 🎉 Choose the best answer for each question!");
                    window.scrollTo({ top: 300, behavior: 'smooth' });
                } else {
                    setResult(fullText);
                    setCharacterMessage("I couldn't make a game this time, but here are some questions for you!");
                }
            } else {
                const stream = await runTutorQueryStream(language, explanationLanguage, mode, topic, studentInput, difficulty, proficiency, recognizedText);
                let currentResult = "";
                for await (const chunk of stream) {
                    currentResult += chunk.text || '';
                    setResult(currentResult);
                }
                setCharacterMessage('Here you go! ✨ Ask me a follow-up if you need to!');
            }
        } catch (e: unknown) {
            if (e instanceof Error) {
                setError(`An error occurred: ${e.message}`);
            } else {
                setError('An unknown error occurred.');
            }
            setCharacterMessage('Oops! Something went wrong.');
        } finally {
            setIsLoading(false);
        }
    }, [language, explanationLanguage, mode, topic, studentInput]);

    const handleFollowUpSubmit = async () => {
        if (!followUpInput.trim() || !lastQuery || !result) return;

        setIsLoading(true);
        setError(null);
        const followUpText = followUpInput;
        setFollowUpInput('');
        setCharacterMessage('Thinking about your question... 🤔');

        const formattedFollowUp = 
            `<hr class="my-6 border-slate-300 dark:border-slate-600">\n\n` +
            `<div class="p-4 bg-yellow-50 dark:bg-yellow-900/50 rounded-lg border border-yellow-300 dark:border-yellow-700 mb-4">\n` +
            `<strong class="font-semibold text-yellow-800 dark:text-yellow-300">Your Follow-up:</strong>\n`+
            `<p class="mt-1 italic text-slate-600 dark:text-slate-400">${followUpText.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>\n`+
            `</div>\n\n`;

        const resultWithFollowUp = result + formattedFollowUp;
        setResult(resultWithFollowUp);
       
        try {
            const stream = await runFollowUpQueryStream({
                topicLanguage: lastQuery.language,
                explanationLanguage: lastQuery.explanationLanguage,
                mode: lastQuery.mode,
                topic: lastQuery.topic,
                studentInput: lastQuery.studentInput,
                originalResponse: result,
                followUpText,
            });
            
            let responseText = "";
            for await (const chunk of stream) {
                // FIX: handle cases where chunk.text is undefined to avoid appending "undefined" to the result.
                responseText += chunk.text || '';
                setResult(resultWithFollowUp + responseText);
            }
            setCharacterMessage('Here is some more information!');
        } catch (e: unknown) {
             if (e instanceof Error) {
                setError(`An error occurred during follow-up: ${e.message}`);
            } else {
                setError('An unknown error occurred during follow-up.');
            }
            setCharacterMessage('I had a little trouble with that one.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCharacterClick = () => {
        if (result && followUpInputRef.current) {
          followUpInputRef.current.focus();
          setCharacterMessage("Go ahead, ask me anything about the topic!");
        } else {
          setCharacterMessage("Choose your language and topic to get started!");
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };

    return (
        <div className="min-h-screen text-slate-800 dark:text-slate-200">
            {/* Top Taskbar / Header */}
            <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-white/70 dark:bg-slate-900/70 border-b border-slate-200 dark:border-slate-800 shadow-sm">
                <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
                    <div 
                        className="flex items-center gap-3 cursor-pointer group"
                        onClick={() => window.location.reload()}
                    >
                        <div className="animate-scale-in transition-transform group-hover:scale-105">
                            <LgaLogoIcon className="w-12 h-12 drop-shadow-md" />
                        </div>
                        <div className="flex flex-col">
                            <h1 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 dark:from-red-400 dark:to-orange-400 tracking-tight leading-none mb-0.5">
                                LingoLoom
                            </h1>
                            <span className="text-base sm:text-lg font-bold text-slate-500 dark:text-slate-400 tracking-wider ml-0.5 uppercase">
                                Grammar AI
                            </span>
                        </div>
                    </div>
                    <div className="flex items-center gap-4">
                        <button 
                            onClick={toggleTheme}  
                            className="p-2.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-sm border border-slate-200 dark:border-slate-700 hover:scale-105 active:scale-95"
                            aria-label="Toggle theme"
                        >
                            {theme === 'light' ? <MoonIcon className="w-5 h-5"/> : <SunIcon className="w-5 h-5"/>}
                        </button>
                    </div>
                </div>
            </header>

            <div className="max-w-4xl mx-auto p-4 sm:p-6 md:p-8 pb-24">
                <div className="relative text-center mb-10 py-8 px-4 rounded-3xl overflow-hidden group">
                    {/* Background LGA Watermark */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-30 dark:opacity-40 pointer-events-none select-none z-0 transition-opacity duration-500 group-hover:opacity-40 dark:group-hover:opacity-50">
                        <svg viewBox="0 0 500 200" className="w-[120%] h-auto sm:w-[500px]">
                            <defs>
                                <linearGradient id="lga-watermark-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                                    <stop offset="0%" stopColor="#ef4444" />
                                    <stop offset="50%" stopColor="#f97316" />
                                    <stop offset="100%" stopColor="#eab308" />
                                </linearGradient>
                            </defs>
                            <text x="50%" y="54%" dominantBaseline="middle" textAnchor="middle" fontSize="140" fontWeight="900" fill="url(#lga-watermark-grad)" letterSpacing="10">LGA</text>
                        </svg>
                    </div>
                    
                    <h2 className="text-3xl sm:text-4xl font-bold text-slate-800 dark:text-slate-200 relative z-10">
                        Language Mastery Made Simple
                    </h2>
                    <p className="mt-3 text-lg text-slate-600 dark:text-slate-400 font-medium relative z-10 drop-shadow-sm">
                        Your friendly guide to mastering languages!
                    </p>
                </div>

                <main className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 p-6 sm:p-8 space-y-8 relative z-20">
                    {mode === 'Vocabulary SRS' ? (
                        <div className="animate-fade-in">
                            <SrsDeck 
                                language={language}
                                items={srsItems}
                                onUpdateItems={handleSrsUpdate}
                                onGenerateNew={handleGenerateSrsItems}
                                isLoading={isLoading}
                                proficiency={proficiency}
                                explanationLanguage={explanationLanguage}
                            />
                        </div>
                    ) : isQuizActive ? (
                        <QuizComponent 
                            questions={quizQuestions} 
                            language={explanationLanguage}
                            onFinish={(score, total) => {
                                setIsQuizActive(false);
                                setQuizQuestions([]);
                                setMode('Explain'); // Reset to explain or keep current
                                setCharacterMessage(`Fantastic job! You got ${score} out of ${total}! 🎉🎉`);
                            }}
                        />
                    ) : (
                        <>
                            {/* Language Selector */}
                            <div className="space-y-4">
                                <label className="text-lg font-semibold text-slate-700 dark:text-slate-300">1. Choose a Language for Topics</label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            {LANGUAGES.map((lang) => {
                                const colorClass = languageColorClasses[lang];
                                return (
                                    <button
                                        key={lang}
                                        onClick={() => setLanguage(lang)}
                                        className={`px-4 py-3 rounded-lg text-center font-medium transition-all duration-200 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 ${
                                            language === lang
                                                ? `${colorClass.active} shadow-md`
                                                : `bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 ${colorClass.inactive}`
                                        }`}
                                    >
                                        {lang}
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Mode Selector */}
                    <div className="space-y-4">
                        <label className="text-lg font-semibold text-slate-700 dark:text-slate-300">2. Select a Mode</label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            {MODES.map((modeName) => {
                                const colorClass = modeColorClasses[modeName];
                                return (
                                <button
                                    key={modeName}
                                    onClick={() => setMode(modeName)}
                                    className={`flex items-center justify-center px-4 py-3 rounded-lg font-medium transition-all duration-200 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 ${
                                        mode === modeName
                                            ? `${colorClass.active} shadow-md`
                                            : `bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 ${colorClass.inactive}`
                                    }`}
                                >
                                    {getModeIcon(modeName)}
                                    {modeName}
                                </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Topic Selector */}
                    {(mode !== 'Chat' && mode !== 'Learning Path') && (
                        <div className="space-y-4">
                            <label htmlFor="topic-select" className="text-lg font-semibold text-slate-700 dark:text-slate-300">3. Pick a Topic</label>
                            <div className="relative">
                                <select
                                    id="topic-select"
                                    value={topic}
                                    onChange={(e) => setTopic(e.target.value)}
                                    className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none"
                                >
                                    {TOPICS[language].map((t) => (
                                        <option key={t.id} value={t.id}>{t.name}</option>
                                    ))}
                                </select>
                                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-700 dark:text-slate-300">
                                    <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {/* Difficulty Selector for Quiz */}
                    {mode === 'Quiz' && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="space-y-4">
                                <label htmlFor="difficulty-select" className="text-lg font-semibold text-slate-700 dark:text-slate-300">3. Select Difficulty</label>
                                <div className="relative">
                                    <select
                                        id="difficulty-select"
                                        value={difficulty}
                                        onChange={(e) => setDifficulty(e.target.value as Difficulty)}
                                        className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
                                    >
                                        <option value="Easy">Easy</option>
                                        <option value="Medium">Medium</option>
                                        <option value="Hard">Hard</option>
                                    </select>
                                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-700 dark:text-slate-300">
                                        <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <label className="text-lg font-semibold text-slate-700 dark:text-slate-300">4. Number of Questions</label>
                                <div className="grid grid-cols-4 gap-3">
                                    {[10, 25, 50, 100].map(count => (
                                        <button
                                            key={count}
                                            onClick={() => setQuizQuestionCount(count)}
                                            className={`px-4 py-2 rounded-lg font-bold border-2 transition-all ${
                                                quizQuestionCount === count 
                                                ? 'bg-blue-500 text-white border-blue-500 shadow-md' 
                                                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-blue-400'
                                            }`}
                                        >
                                            {count}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {mode === 'Learning Path' && (
                        <div className="space-y-4 animate-fade-in">
                            <label htmlFor="proficiency-select" className="text-lg font-semibold text-slate-700 dark:text-slate-300">3. Select Proficiency</label>
                            <div className="relative">
                                <select
                                    id="proficiency-select"
                                    value={proficiency}
                                    onChange={(e) => setProficiency(e.target.value as any)}
                                    className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none"
                                >
                                    <option value="Beginner">Beginner</option>
                                    <option value="Intermediate">Intermediate</option>
                                    <option value="Advanced">Advanced</option>
                                </select>
                                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-700 dark:text-slate-300">
                                    <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {mode === 'Correct' && (
                        <div className="space-y-4 animate-fade-in">
                            <label htmlFor="student-input" className="text-lg font-semibold text-slate-700 dark:text-slate-300">
                                4. Enter Text to Correct
                            </label>
                            <textarea
                                id="student-input"
                                value={studentInput}
                                onChange={(e) => setStudentInput(e.target.value)}
                                placeholder={`Enter a sentence in ${language} to be checked...`}
                                className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 h-28"
                            />
                        </div>
                    )}

                    {mode === 'Pronounce' && (
                        <div className="space-y-4 animate-fade-in">
                            <label htmlFor="target-sentence" className="text-lg font-semibold text-slate-700 dark:text-slate-300">
                                4. Enter Target Sentence
                            </label>
                            <input
                                id="target-sentence"
                                type="text"
                                value={studentInput}
                                onChange={(e) => setStudentInput(e.target.value)}
                                placeholder={`Enter the sentence in ${language} you want to practice...`}
                                className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                            />

                            <label className="text-lg font-semibold text-slate-700 dark:text-slate-300 block mt-4">
                                5. Record Your Voice
                            </label>
                            <div className="flex items-center gap-4">
                                <button
                                    onClick={isRecording ? () => recognitionRef.current?.stop() : startRecording}
                                    className={`flex items-center justify-center p-4 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 ${
                                        isRecording ? 'bg-red-500 hover:bg-red-600 text-white shadow-[0_0_15px_rgba(239,68,68,0.6)] animate-pulse' : 'bg-pink-500 hover:bg-pink-600 text-white'
                                    }`}
                                >
                                    <MicIcon className="w-6 h-6" />
                                </button>
                                <div className="flex-1">
                                    <input
                                        type="text"
                                        readOnly
                                        value={recognizedText}
                                        placeholder="Your spoken text will appear here..."
                                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700/50 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-600 dark:text-slate-400"
                                    />
                                </div>
                            </div>
                        </div>
                    )}

                    {mode === 'Chat' && (
                        <div className="space-y-4 animate-fade-in">
                            <label htmlFor="chat-input" className="text-lg font-semibold text-slate-700 dark:text-slate-300">
                                3. Ask LingoLoom Anything
                            </label>
                            <textarea
                                id="chat-input"
                                value={studentInput}
                                onChange={(e) => setStudentInput(e.target.value)}
                                placeholder="E.g., What is the difference between affect and effect?"
                                className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 h-28"
                            />
                        </div>
                    )}

                    {/* Explanation Language Selector */}
                    {(mode !== 'Chat' && mode !== 'Learning Path' && mode !== 'Vocabulary SRS') && (
                         <div className="space-y-4">
                            <label htmlFor="explanation-lang" className="text-lg font-semibold text-slate-700 dark:text-slate-300">
                                {mode === 'Correct' ? '5.' : mode === 'Pronounce' ? '6.' : mode === 'Quiz' ? '5.' : '4.'} Get Explanation In
                            </label>
                            <div className="relative">
                                <select
                                    id="explanation-lang"
                                    value={explanationLanguage}
                                    onChange={(e) => setExplanationLanguage(e.target.value as Language)}
                                    className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none"
                                >
                                    {LANGUAGES.map((lang) => (
                                        <option key={lang} value={lang}>
                                            {lang}
                                        </option>
                                    ))}
                                </select>
                                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-700 dark:text-slate-300">
                                    <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Submit Button */}
                    <div className="pt-4">
                        <button
                            onClick={handleSubmit}
                            disabled={isLoading}
                            className={`w-full flex items-center justify-center gap-3 px-6 py-4 text-white font-bold text-lg rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100 ${
                                mode === 'Chat' ? 'bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 focus:ring-purple-300 dark:focus:ring-purple-800' :
                                'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 focus:ring-green-300 dark:focus:ring-green-800'
                            }`}
                        >
                            {isLoading ? <Loader text="Thinking..."/> : (
                                <div className="flex items-center gap-3">
                                    {mode === 'Learning Path' && <MapIcon className="w-6 h-6" />}
                                    {mode === 'Pronounce' && <MicIcon className="w-6 h-6" />}
                                    {(mode !== 'Learning Path' && mode !== 'Pronounce') && <SparklesIcon className="w-6 h-6" />}
                                    
                                    <span>
                                        {mode === 'Chat' 
                                            ? 'Ask LingoLoom' 
                                            : mode === 'Learning Path' 
                                                ? 'Generate Path' 
                                                : mode === 'Pronounce' 
                                                    ? 'Check Pronunciation' 
                                                    : 'Ask LingoLoom!'}
                                    </span>
                                </div>
                            )}
                        </button>
                    </div>
                </>
            )}
        </main>
                
                {error && <div className="mt-6 p-4 bg-red-100 dark:bg-red-900/50 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-300 rounded-lg">{error}</div>}

                <div className="mt-8">
                    {result ? (
                        <div className="space-y-6">
                            <ResultDisplay content={result} language={explanationLanguage} mode={mode} />
                            <div className="relative">
                                <input
                                    ref={followUpInputRef}
                                    type="text"
                                    value={followUpInput}
                                    onChange={(e) => setFollowUpInput(e.target.value)}
                                    placeholder="Ask a follow-up question..."
                                    className="w-full pl-4 pr-12 py-3 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-full focus:outline-none focus:ring-2 focus:ring-orange-500"
                                    onKeyPress={(e) => e.key === 'Enter' && handleFollowUpSubmit()}
                                />
                                <button
                                    onClick={handleFollowUpSubmit}
                                    disabled={isLoading || !followUpInput.trim()}
                                    className="absolute inset-y-0 right-0 flex items-center justify-center w-12 h-full text-orange-500 dark:text-orange-400 disabled:text-slate-400 dark:disabled:text-slate-500 hover:bg-orange-100 dark:hover:bg-orange-900/50 rounded-r-full transition-colors"
                                    aria-label="Send follow-up"
                                >
                                    <SendIcon className="w-6 h-6"/>
                                </button>
                            </div>
                        </div>
                    ) : (
                        !isLoading && (
                            <div className="text-center p-8 bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700">
                                <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-300">{getWelcomeMessage(language)}</h2>

                                <p className="mt-2 text-slate-500 dark:text-slate-400">Ready to learn? Choose your options above and let's get started!</p>
                            </div>
                        )
                    )}
                </div>

                <footer className="text-center mt-16 text-sm text-slate-500 dark:text-slate-400 flex flex-col items-center gap-4 relative z-40 pb-20">
                    <div className="border-t border-b border-slate-300 dark:border-slate-600 py-3 my-2 w-full max-w-sm rounded-lg bg-white/50 dark:bg-slate-800/50 shadow-sm pointer-events-none">
                        <p className="font-bold tracking-widest text-slate-700 dark:text-slate-200 uppercase">Made by MANASVI PARMAR</p>
                    </div>
                    <div className="flex flex-wrap justify-center gap-6 font-medium">
                        <button 
                            type="button"
                            onClick={() => {
                                setInfoModal({title: 'Terms and Conditions', content: (
                                    <div className="space-y-3">
                                        <p>By using LingoLoom Grammar AI, you agree to respect the AI and use it for educational purposes. We strive to provide accurate translations and grammar checks, however, users must exercise their own judgment. The contents provided are AI-generated and can sometimes be inaccurate.</p>
                                        <p>You agree not to misuse the platform for generating harmful, illegal, or malicious content. The services are provided "as is" without any warranties. Your continued use of the application signifies your acceptance of these terms.</p>
                                        <p>We reserve the right to modify these terms at any time without prior notice. Please use this tool responsibly to master languages.</p>
                                    </div>
                                )});
                            }} 
                            className="hover:text-orange-500 transition-colors cursor-pointer py-2 px-4 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700"
                        >
                            Terms and Conditions
                        </button>
                        <button 
                            type="button"
                            onClick={() => {
                                setInfoModal({title: 'Privacy Policy', content: (
                                    <div className="space-y-3">
                                        <p>We deeply respect your privacy. LingoLoom Grammar AI does not persistently store your personal queries, translations, or verbal inputs on our servers. All analysis is processed instantly in real-time via the Gemini API to provide you with immediate educational feedback.</p>
                                        <p>We do not collect or sell your personal data to third parties. Minimal browser-level information may be utilized to maintain performance constraints. User preferences (like theme and language) are stored locally on your device.</p>
                                        <p>If you have any further questions about how your data is handled, please enjoy the app knowing everything is geared towards giving you the best learning experience securely.</p>
                                    </div>
                                )});
                            }} 
                            className="hover:text-orange-500 transition-colors cursor-pointer py-2 px-4 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700"
                        >
                            Privacy Policy
                        </button>
                        <button 
                            type="button"
                            onClick={() => {
                                const isGu = explanationLanguage === 'gu-IN';
                                const isHi = explanationLanguage === 'hi-IN';
                                const isSa = explanationLanguage === 'sa-IN';
                                
                                setInfoModal({title: isGu ? 'LingoLoom નો ઉપયોગ કેવી રીતે કરવો' : isHi ? 'LingoLoom का उपयोग कैसे करें' : isSa ? 'लिङ्गोलूमस्य उपयोगं कथं कुर्यात्' : 'How to use LingoLoom', content: (
                                    <div className="space-y-4">
                                        <div className="flex items-start gap-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                                            <span className="text-2xl mt-1">📝</span>
                                            <div>
                                                <h4 className="font-bold text-slate-800 dark:text-slate-200">
                                                    {isGu ? 'વાક્ય અથવા વિષય (Explain)' : isHi ? 'वाक्य या विषय (Explain)' : isSa ? 'वाक्यं वा विषयः (Explain)' : 'Explain Mode'}
                                                </h4>
                                                <p className="text-slate-600 dark:text-slate-300">
                                                    {isGu ? 'તમારો કોઈપણ પ્રશ્ન લખો અને AI વિસ્તારમાં સમજાવશે.' : isHi ? 'अपना प्रश्न लिखें और AI उसे विस्तार से समझाएगा।' : isSa ? 'स्वस्य प्रश्नं लिखन्तु, AI विस्तारेण वर्णयिष्यति।' : 'Write your question and AI will explain it in detail.'}
                                                </p>
                                            </div>
                                        </div>
                                        
                                        <div className="flex items-start gap-3 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                                            <span className="text-2xl mt-1">🎯</span>
                                            <div>
                                                <h4 className="font-bold text-slate-800 dark:text-slate-200">
                                                    {isGu ? 'ફક્ત જવાબ માપપટ્ટી (Fix Only)' : isHi ? 'केवल सही उत्तर (Fix Only)' : isSa ? 'केवलम् उत्तरम् (Fix Only)' : 'Fix Only Mode'}
                                                </h4>
                                                <p className="text-slate-600 dark:text-slate-300">
                                                    {isGu ? 'સમજૂતી વગર સીધો સાચો જવાબ મેળવવા માટે.' : isHi ? 'बिना स्पष्टीकरण के सीधा सही उत्तर प्राप्त करने के लिए।' : isSa ? 'विना स्पष्टीकरणेन साक्षात् शुद्धम् उत्तरं प्राप्तुम्।' : 'Get the correct answer directly without explanation.'}
                                                </p>
                                            </div>
                                        </div>
                                        
                                        <div className="flex items-start gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                            <span className="text-2xl mt-1">🗣️</span>
                                            <div>
                                                <h4 className="font-bold text-slate-800 dark:text-slate-200">
                                                    {isGu ? 'અવાજ થી પ્રશ્ન (Voice Input)' : isHi ? 'आवाज़ से प्रश्न (Voice Input)' : isSa ? 'वाचा प्रश्नः (Voice Input)' : 'Voice Input'}
                                                </h4>
                                                <p className="text-slate-600 dark:text-slate-300">
                                                    {isGu ? 'માઈક આઇકોન પર ક્લિક કરી બોલીને પ્રશ્ન પૂછો.' : isHi ? 'माइक आइकन पर क्लिक करें और बोलकर प्रश्न पूछें।' : isSa ? 'माइक-चिह्ने क्लिक् कृत्वा वदन् प्रश्नं पृच्छतु।' : 'Click the mic icon and speak your question.'}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                )});
                            }} 
                            className="hover:text-orange-500 transition-colors cursor-pointer py-2 px-4 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700"
                        >
                            Help
                        </button>
                    </div>
                </footer>
            </div>
            <Character
                message={characterMessage}
                onClick={handleCharacterClick}
                language={explanationLanguage}
            />
            
            {infoModal && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
                    <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl relative">
                        <button onClick={() => setInfoModal(null)} className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white">
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                        </button>
                        <h2 className="text-xl font-bold mb-4 text-slate-800 dark:text-white pr-8">{infoModal.title}</h2>
                        <div className="text-slate-600 dark:text-slate-300 mb-2 text-xs sm:text-sm max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
                            {infoModal.content}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default App;
