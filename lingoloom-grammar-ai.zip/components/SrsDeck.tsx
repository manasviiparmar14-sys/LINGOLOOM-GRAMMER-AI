
import React, { useState } from 'react';
import { Language, SRSItem } from '../types';
import { SparklesIcon, BrainCircuitIcon } from './icons';

interface SrsDeckProps {
  language: Language;
  proficiency: string;
  explanationLanguage: Language;
  onUpdateItems: (items: SRSItem[]) => void;
  items: SRSItem[];
  onGenerateNew: () => void;
  isLoading: boolean;
}

const SrsDeck: React.FC<SrsDeckProps> = ({ 
  language, 
  items, 
  onUpdateItems, 
  onGenerateNew,
  isLoading 
}) => {
  const [showAnswer, setShowAnswer] = useState(false);

  const reviewItems = items.filter(item => 
    item.language === language && item.nextReview <= Date.now()
  );

  const handleLevelUp = (levelDelta: number) => {
    if (reviewItems.length === 0) return;
    
    const currentItem = reviewItems[0];
    const newLevel = Math.max(0, Math.min(5, currentItem.level + levelDelta));
    
    // SRS Intervals: Immediate, 1d, 3d, 7d, 14d, 30d
    const intervals = [0, 24 * 3600 * 1000, 3 * 24 * 3600 * 1000, 7 * 24 * 3600 * 1000, 14 * 24 * 3600 * 1000, 30 * 24 * 3600 * 1000];
    const nextInterval = intervals[newLevel];
    
    const updatedItem = {
      ...currentItem,
      level: newLevel,
      lastSeen: Date.now(),
      nextReview: Date.now() + nextInterval
    };
    
    // Remove current from items and push to end of array to cycle queue
    const updatedItems = items.filter(item => item.id !== currentItem.id);
    updatedItems.push(updatedItem);

    onUpdateItems(updatedItems);
    setShowAnswer(false);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-12 space-y-4">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-500"></div>
        <p className="text-slate-600 dark:text-slate-400 font-medium">Aariya is picking special words for you...</p>
      </div>
    );
  }

  if (reviewItems.length === 0) {
    return (
      <div className="text-center p-8 bg-rose-50 dark:bg-rose-900/20 rounded-2xl border border-rose-200 dark:border-rose-800 animate-fade-in">
        <BrainCircuitIcon className="w-16 h-16 text-rose-500 mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">Deck is Clear!</h3>
        <p className="text-slate-600 dark:text-slate-400 mb-6">You've mastered all your current words for {language}.</p>
        <button
          onClick={onGenerateNew}
          className="inline-flex items-center gap-2 px-6 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl shadow-lg transition-transform hover:scale-105"
        >
          <SparklesIcon className="w-5 h-5" />
          Get 10 New Words
        </button>
      </div>
    );
  }

  const currentItem = reviewItems[0];

  return (
    <div className="max-w-md mx-auto space-y-6 animate-fade-in">
      <div className="flex justify-between items-center px-2">
        <span className="text-sm font-medium text-slate-500">Remaining: {reviewItems.length}</span>
        <span className="text-xs px-2 py-1 bg-rose-100 dark:bg-rose-900/50 text-rose-600 dark:text-rose-400 rounded-full font-bold">Level {currentItem.level}</span>
      </div>

      <div className="aspect-[4/3] relative perspective-1000">
        <div 
          className={`w-full h-full relative transition-transform duration-500 transform-style-3d cursor-pointer ${showAnswer ? 'rotate-y-180' : ''}`}
          onClick={() => setShowAnswer(!showAnswer)}
        >
          {/* Front */}
          <div className="absolute inset-0 backface-hidden bg-white dark:bg-slate-800 rounded-3xl shadow-xl border-2 border-rose-200 dark:border-rose-900 flex flex-col items-center justify-center p-8">
            <p className="text-sm text-slate-400 mb-2 uppercase tracking-widest font-bold">Word</p>
            <h2 className="text-5xl font-bold text-slate-800 dark:text-white text-center">{currentItem.word}</h2>
            <p className="mt-8 text-rose-400 text-sm font-medium animate-pulse">Tap to see meaning</p>
          </div>

          {/* Back */}
          <div className="absolute inset-0 backface-hidden rotate-y-180 bg-rose-50 dark:bg-slate-700 rounded-3xl shadow-xl border-2 border-rose-300 dark:border-rose-800 flex flex-col items-center justify-center p-8 overflow-y-auto">
            <p className="text-sm text-rose-400 mb-2 uppercase tracking-widest font-bold">Meaning</p>
            <h2 className="text-3xl font-bold text-slate-800 dark:text-white text-center mb-6">{currentItem.translation}</h2>
            {/* Example could be added here if stored */}
            <p className="text-slate-400 text-xs italic">Level {currentItem.level} → Next review in {currentItem.level === 0 ? '1 day' : currentItem.level === 1 ? '3 days' : currentItem.level === 2 ? '7 days' : 'longer'}</p>
          </div>
        </div>
      </div>

      {showAnswer && (
        <div className="grid grid-cols-2 gap-4 animate-scale-in">
          <button
            onClick={() => handleLevelUp(-1)}
            className="px-6 py-4 bg-slate-200 dark:bg-slate-700 hover:bg-red-100 dark:hover:bg-red-900/30 text-slate-700 dark:text-slate-300 font-bold rounded-2xl transition-colors"
          >
            Hard (Level Down)
          </button>
          <button
            onClick={() => handleLevelUp(1)}
            className="px-6 py-4 bg-green-500 hover:bg-green-600 text-white font-bold rounded-2xl shadow-lg transition-transform hover:scale-105"
          >
            Easy (Level Up!)
          </button>
        </div>
      )}
    </div>
  );
};

export default SrsDeck;
