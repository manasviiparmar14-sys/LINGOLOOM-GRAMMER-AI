
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { Language, Mode, Proficiency } from '../types';
import { SYSTEM_INSTRUCTION } from '../constants';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function runTutorQueryStream(
    topicLanguage: Language,
    explanationLanguage: Language,
    mode: Mode,
    topic: string,
    studentInput: string,
    difficulty?: string,
    proficiency?: Proficiency,
    recognizedText?: string
): Promise<AsyncGenerator<GenerateContentResponse>> {
    try {
        const userPrompt = `
Language: ${explanationLanguage}
Mode: ${mode}
Topic: ${topic} (from ${topicLanguage} grammar)
${mode === 'Quiz' && difficulty ? `Difficulty: ${difficulty}` : ''}
${mode === 'Learning Path' && proficiency ? `Proficiency: ${proficiency}` : ''}
${(mode === 'Correct' || mode === 'Pronounce') ? `Student Input: ${studentInput}` : ''}
${mode === 'Pronounce' ? `Spoken Input: ${recognizedText || 'None'}` : ''}
`;
        return ai.models.generateContentStream({
            model: 'gemini-3-flash-preview', // MUCH faster for user experience
            contents: userPrompt,
            config: {
                systemInstruction: SYSTEM_INSTRUCTION,
            },
        });
        
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to get a response from the AI tutor. Please check your API key and try again.");
    }
}

export interface FollowUpQuery {
    topicLanguage: Language;
    explanationLanguage: Language;
    mode: Mode;
    topic: string;
    studentInput: string;
    originalResponse: string;
    followUpText: string;
}

export async function runFollowUpQueryStream(params: FollowUpQuery): Promise<AsyncGenerator<GenerateContentResponse>> {
    const { topicLanguage, explanationLanguage, mode, topic, studentInput, originalResponse, followUpText } = params;
    
    try {
        const userPrompt = `
You are in a continued conversation. Here is the original context:
- Topic Language: ${topicLanguage}
- Explanation Language: ${explanationLanguage}
- Mode: ${mode}
- Topic: ${topic}
${mode === 'Correct' && studentInput ? `- Original Student Input: ${studentInput}` : ''}

Your previous response (in ${explanationLanguage}) was:
---
${originalResponse.replace(/<[^>]*>?/gm, '')}
---

The student now has a follow-up question, comment, or correction:
"${followUpText}"

Please respond to this follow-up. Address their point directly, correct yourself if necessary, or provide further clarification. Maintain your friendly 'LingoLoom' persona and use the ${explanationLanguage} language for your entire response.
`;
        
        return ai.models.generateContentStream({
            model: 'gemini-3-flash-preview', // Fast AI responses
            contents: userPrompt,
            config: {
                systemInstruction: SYSTEM_INSTRUCTION
            },
        });
        
    } catch (error) {
        console.error("Error calling Gemini API during follow-up:", error);
        throw new Error("Failed to get a follow-up response from the AI tutor.");
    }
}

export async function runChatQueryStream(message: string): Promise<AsyncGenerator<GenerateContentResponse>> {
    try {
        const chat = ai.chats.create({
            model: "gemini-3-flash-preview",
            config: {
                systemInstruction: "You are a helpful AI chatbot assistant for a grammar learning app. Answer questions clearly and concisely.",
            },
        });
        return await chat.sendMessageStream({ message });
    } catch (error) {
        console.error("Error calling Gemini API for chat:", error);
        throw new Error("Failed to get a chat response.");
    }
}
