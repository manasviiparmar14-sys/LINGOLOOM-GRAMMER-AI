
export type Language = 'Gujarati' | 'Hindi' | 'Sanskrit' | 'English';

export type Mode = 'Explain' | 'Practice' | 'Correct' | 'Quiz' | 'Chat' | 'Pronounce' | 'Learning Path' | 'Vocabulary SRS';

export interface SRSItem {
  id: string;
  word: string;
  translation: string;
  language: Language;
  level: number; // 0 = New, 1 = Learning, 2 = Review, 3 = Mastery
  lastSeen: number;
  nextReview: number;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation?: string;
}

export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export type Proficiency = 'Beginner' | 'Intermediate' | 'Advanced';

export interface Topic {
  id: string;
  name: string;
}

export type Topics = Record<Language, Topic[]>;

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}
