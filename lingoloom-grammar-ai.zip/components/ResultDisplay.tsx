import React, { useState, useEffect } from 'react';
import { Language, Mode } from '../types';
import Markdown from 'react-markdown';
import { SpeakerIcon } from './icons';
import { getLangCode } from '../constants';

interface ResultDisplayProps {
  content: string;
  language: Language;
  mode?: Mode;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ content, language, mode }) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
        const loadVoices = () => {
            const availableVoices = window.speechSynthesis.getVoices();
            if (availableVoices.length > 0) {
                setVoices(availableVoices);
            }
        };
        
        loadVoices();
        if (typeof window !== 'undefined' && window.speechSynthesis) {
            window.speechSynthesis.onvoiceschanged = loadVoices;
        }
  }, []);

  useEffect(() => {
      return () => {
          if (speechSynthesis.speaking) {
              speechSynthesis.cancel();
          }
          setIsSpeaking(false);
      };
  }, []);

  const handleSpeak = () => {
      if (isSpeaking) {
          speechSynthesis.cancel();
          setIsSpeaking(false);
          return;
      }
      
      if (!content || typeof window.speechSynthesis === 'undefined') {
          return;
      }
      
      speechSynthesis.cancel();

      const plainText = new DOMParser().parseFromString(content, 'text/html').body.textContent || "";
      if (!plainText.trim()) return;

      const utterance = new SpeechSynthesisUtterance(plainText);
      let langCode = language === 'Gujarati' ? 'gu-IN' : language === 'Hindi' || language === 'Sanskrit' ? 'hi-IN' : 'en-US';
      utterance.lang = langCode;
      
      utterance.volume = 1;
      utterance.rate = 1;
      utterance.pitch = 1.4; // Higher pitch for a more female/cute voice

      let selectedVoice = voices.find(v => v.lang.includes(langCode.split('-')[0]) && (v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('girl')));
      
      if (!selectedVoice) selectedVoice = voices.find(v => v.lang.includes(langCode.split('-')[0]));
      if (!selectedVoice) selectedVoice = voices.find(v => v.lang.includes('en-IN') && v.name.toLowerCase().includes('female'));
      if (!selectedVoice) selectedVoice = voices.find(v => v.lang.includes('hi'));
      
      if (selectedVoice) {
          utterance.voice = selectedVoice;
      }
      
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = (event) => {
          if (event.error !== 'interrupted' && event.error !== 'not-allowed') {
            console.error("Speech synthesis error:", event.error);
          }
          setIsSpeaking(false);
      };
      
      speechSynthesis.speak(utterance);
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 p-6 sm:p-8 animate-fade-in relative">
      <button
          onClick={handleSpeak}
          className={`absolute top-4 right-4 p-2 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-800 ${
              isSpeaking 
              ? 'bg-red-500 text-white hover:bg-red-600 focus:ring-red-500' 
              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 focus:ring-orange-500'
          }`}
          aria-label={isSpeaking ? "Stop speaking" : "Read result aloud"}
      >
          <SpeakerIcon className="w-5 h-5" />
      </button>
      {mode === 'Chat' ? (
        <div className="prose prose-slate dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 pr-10">
          <Markdown>{content}</Markdown>
        </div>
      ) : (
        <div 
          className="prose prose-slate dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed pr-10"
          dangerouslySetInnerHTML={{ __html: content }}
        />
      )}
    </div>
  );
};

export default ResultDisplay;