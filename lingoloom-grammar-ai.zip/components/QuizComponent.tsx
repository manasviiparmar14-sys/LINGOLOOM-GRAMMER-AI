import React, { useState, useEffect } from 'react';
import { QuizQuestion, Language } from '../types';
import { CheckCircleIcon, XCircleIcon, ArrowRightIcon, TrophyIcon, RotateCcwIcon, BrainCircuitIcon } from './icons';

interface QuizComponentProps {
  questions: QuizQuestion[];
  onFinish: (score: number, total: number) => void;
  language: Language;
}

const QuizComponent: React.FC<QuizComponentProps> = ({ questions, onFinish, language }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const currentQuestion = questions[currentIdx];

  const handleOptionClick = (option: string) => {
    if (isAnswerChecked) return;
    setSelectedOption(option);
  };

  const handleCheckAnswer = () => {
    if (!selectedOption) return;
    if (selectedOption === currentQuestion.correctAnswer) {
      setScore(prev => prev + 1);
    }
    setIsAnswerChecked(true);
  };

  const handleNext = () => {
    setSelectedOption(null);
    setIsAnswerChecked(false);
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(prev => prev + 1);
    } else {
      setShowResult(true);
    }
  };

  if (showResult) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="text-center p-8 bg-white dark:bg-slate-800 rounded-3xl shadow-xl border-2 border-orange-200 dark:border-orange-900 animate-scale-in">
        <TrophyIcon className="w-20 h-20 text-orange-500 mx-auto mb-6 animate-bounce" />
        <h2 className="text-4xl font-bold text-slate-800 dark:text-white mb-4">Quiz Complete! 🎉🎉</h2>
        <div className="text-6xl font-black text-orange-500 mb-6">{percentage}%</div>
        <p className="text-xl text-slate-600 dark:text-slate-400 mb-8">
          You scored <span className="font-bold text-orange-600">{score}</span> out of <span className="font-bold text-orange-600">{questions.length}</span> questions correctly.
        </p>
        
        <div className="mt-8 space-y-4">
          <p className="text-lg font-medium text-slate-700 dark:text-slate-300 italic">
            {percentage >= 90 ? "Excellent! You're a master! 🌟" : 
             percentage >= 70 ? "Great job! Keep it up! 👍" :
             percentage >= 40 ? "Good effort! Let's review and try again! 📚" :
             "Don't worry, every mistake is a step towards learning! 💪"}
          </p>
          <button 
            onClick={() => onFinish(score, questions.length)}
            className="inline-flex items-center gap-2 px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl shadow-lg transition-transform hover:scale-105"
          >
            <RotateCcwIcon className="w-5 h-5" />
            Try Another Quiz
          </button>
        </div>
      </div>
    );
  }

  if (!questions || questions.length === 0) return null;

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fade-in">
      {/* Progress Header */}
      <div className="flex justify-between items-center px-2">
        <div className="flex flex-col">
           <span className="text-sm font-bold text-orange-500 uppercase tracking-widest">Question</span>
           <span className="text-2xl font-black text-slate-800 dark:text-white">{currentIdx + 1} of {questions.length}</span>
        </div>
        <div className="w-32 h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-orange-500 transition-all duration-500 ease-out" 
            style={{ width: `${((currentIdx + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-lg border border-slate-200 dark:border-slate-700">
        <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-8">
          {currentQuestion.question}
        </h3>

        <div className="grid grid-cols-1 gap-4">
          {currentQuestion.options.map((option, idx) => {
            let bgColor = "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-orange-500 hover:bg-orange-50 dark:hover:bg-orange-900/20";
            let textColor = "text-slate-700 dark:text-slate-300";
            
            if (isAnswerChecked) {
              if (option === currentQuestion.correctAnswer) {
                bgColor = "bg-green-100 dark:bg-green-900/30 border-green-500";
                textColor = "text-green-700 dark:text-green-300";
              } else if (option === selectedOption) {
                bgColor = "bg-red-100 dark:bg-red-900/30 border-red-500";
                textColor = "text-red-700 dark:text-red-300";
              }
            } else if (selectedOption === option) {
              bgColor = "bg-orange-500 border-orange-500";
              textColor = "text-white";
            }

            return (
              <button
                key={idx}
                onClick={() => handleOptionClick(option)}
                disabled={isAnswerChecked}
                className={`w-full p-5 text-left rounded-2xl border-2 transition-all duration-200 font-medium ${bgColor} ${textColor} flex items-center justify-between group`}
              >
                <span>{option}</span>
                {isAnswerChecked && option === currentQuestion.correctAnswer && (
                  <CheckCircleIcon className="w-6 h-6 text-green-500" />
                )}
                {isAnswerChecked && option === selectedOption && option !== currentQuestion.correctAnswer && (
                  <XCircleIcon className="w-6 h-6 text-red-500" />
                )}
                {!isAnswerChecked && !selectedOption && (
                    <div className="w-6 h-6 rounded-full border-2 border-slate-300 dark:border-slate-600 group-hover:border-orange-500" />
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback Area */}
        {isAnswerChecked && (
          <div className="mt-8 p-6 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-700 animate-slide-up">
            <div className="flex items-start gap-3">
              <BrainCircuitIcon className={`w-6 h-6 mt-1 flex-shrink-0 ${selectedOption === currentQuestion.correctAnswer ? 'text-green-500' : 'text-red-500'}`} />
              <div className="space-y-1">
                 <p className="font-bold text-slate-800 dark:text-white">
                   {selectedOption === currentQuestion.correctAnswer ? "Excellent! 🎉" : "Oops! Not quite. 💡"}
                 </p>
                 <p className="text-slate-600 dark:text-slate-400">
                   {currentQuestion.explanation}
                 </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action Footer */}
      <div className="flex justify-center">
        {!isAnswerChecked ? (
          <button
            onClick={handleCheckAnswer}
            disabled={!selectedOption}
            className={`px-10 py-4 font-bold rounded-2xl shadow-lg transition-all ${
              selectedOption 
              ? 'bg-orange-500 text-white hover:bg-orange-600 hover:scale-105 active:scale-95' 
              : 'bg-slate-200 dark:bg-slate-700 text-slate-400 cursor-not-allowed'
            }`}
          >
            Check Answer
          </button>
        ) : (
          <button
            onClick={handleNext}
            className="inline-flex items-center gap-2 px-10 py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl shadow-lg transition-transform hover:scale-105 active:scale-95 animate-scale-in"
          >
            {currentIdx < questions.length - 1 ? (
              <>
                Next Question
                <ArrowRightIcon className="w-5 h-5" />
              </>
            ) : (
              "Finish Quiz"
            )}
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizComponent;
