import React, { useState, useEffect, useRef } from 'react';
import { Language } from '../types';
import { SpeakerIcon } from './icons';
import { getLangCode } from '../constants';
import { motion } from 'motion/react';

interface CharacterProps {
  message: string;
  onClick: () => void;
  language: Language;
}

const Character: React.FC<CharacterProps> = ({ message, onClick, language }) => {
    const [isVisible, setIsVisible] = useState(false);
    const [isSelfSpeaking, setIsSelfSpeaking] = useState(false);
    const [isGlobalSpeaking, setIsGlobalSpeaking] = useState(false);
    const [hasInteracted, setHasInteracted] = useState(false);
    const [mouthOpen, setMouthOpen] = useState(false);
    const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
    const [showTooltip, setShowTooltip] = useState(true);
    const prevMessageRef = useRef<string | undefined>(undefined);
    const tooltipTimerRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        const loadVoices = () => {
            const availableVoices = window.speechSynthesis.getVoices();
            if (availableVoices.length > 0) {
                setVoices(availableVoices);
            }
        };
        
        loadVoices();
        if (typeof window !== 'undefined' && window.speechSynthesis) {
            window.speechSynthesis.onvoiceschanged = loadVoices;
        }
    }, []);

    useEffect(() => {
        let interval: NodeJS.Timeout;
        const checkSpeech = () => {
            if (window.speechSynthesis && window.speechSynthesis.speaking) {
                setMouthOpen(prev => !prev);
                setIsGlobalSpeaking(true);
            } else {
                setMouthOpen(false);
                setIsGlobalSpeaking(false);
            }
        };
        interval = setInterval(checkSpeech, 150);
        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        const handleInteraction = () => setHasInteracted(true);
        window.addEventListener('click', handleInteraction, { once: true });
        window.addEventListener('keydown', handleInteraction, { once: true });
        window.addEventListener('touchstart', handleInteraction, { once: true });

        const timer = setTimeout(() => setIsVisible(true), 500);
        return () => {
            clearTimeout(timer);
            window.removeEventListener('click', handleInteraction);
            window.removeEventListener('keydown', handleInteraction);
            window.removeEventListener('touchstart', handleInteraction);
        };
    }, []);

    const handleSpeak = (textToSpeak: string = message) => {
        if (isSelfSpeaking) {
            speechSynthesis.cancel();
            setIsSelfSpeaking(false);
            setShowTooltip(false);
            return;
        }
        
        if (!textToSpeak || typeof window.speechSynthesis === 'undefined') {
            return;
        }
        
        speechSynthesis.cancel();

        const plainText = new DOMParser().parseFromString(textToSpeak, 'text/html').body.textContent || "";
        if (!plainText.trim()) return;

        const utterance = new SpeechSynthesisUtterance(plainText);
        
        let langCode = language === 'Gujarati' ? 'gu-IN' : language === 'Hindi' || language === 'Sanskrit' ? 'hi-IN' : 'en-US';
        utterance.lang = langCode;
        
        utterance.volume = 1;
        utterance.rate = 0.95; // Slightly slower for better clarity
        utterance.pitch = 1.2; // Natural pitch, not too high

        // Try to find premium "Google" voices first for better clarity
        let preferredVoices = voices.filter(v => v.lang.includes(langCode.split('-')[0]));
        let selectedVoice = preferredVoices.find(v => v.name.includes('Google') && (v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('girl') || langCode === 'hi-IN' || langCode === 'gu-IN'));
        
        if (!selectedVoice) selectedVoice = preferredVoices.find(v => v.name.includes('Google'));
        if (!selectedVoice) selectedVoice = preferredVoices.find(v => v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('girl'));
        if (!selectedVoice && preferredVoices.length > 0) selectedVoice = preferredVoices[0];
        
        // Fallbacks
        if (!selectedVoice) selectedVoice = voices.find(v => v.name.includes('Google') && v.lang.includes('en-IN'));
        if (!selectedVoice) selectedVoice = voices.find(v => v.lang.includes('hi'));
        
        if (selectedVoice) {
            utterance.voice = selectedVoice;
        }
        
        utterance.onstart = () => {
            setIsSelfSpeaking(true);
            setShowTooltip(true);
            if (tooltipTimerRef.current) clearTimeout(tooltipTimerRef.current);
        };
        utterance.onend = () => {
            setIsSelfSpeaking(false);
            // Auto hide tooltip shortly after speaking
            tooltipTimerRef.current = setTimeout(() => setShowTooltip(false), 2000);
        };
        utterance.onerror = (event) => {
            if (event.error !== 'interrupted' && event.error !== 'not-allowed') {
              console.error("Character speech synthesis error:", event.error);
            }
            setIsSelfSpeaking(false);
            setTimeout(() => setShowTooltip(false), 2000);
        };
        
        speechSynthesis.speak(utterance);
    };

    // We use a ref to track the LAST SPOKEN message, so we don't re-speak it immediately unless requested,
    // but we trigger it to speak when a new message comes in.
    useEffect(() => {
        if (message && message !== prevMessageRef.current) {
            setShowTooltip(true);
            if (tooltipTimerRef.current) clearTimeout(tooltipTimerRef.current);
            
            if (hasInteracted && voices.length > 0) {
                handleSpeak(message);
            } else {
                // If it can't speak automatically, hide tooltip after 8 seconds
                tooltipTimerRef.current = setTimeout(() => setShowTooltip(false), 8000);
            }
            prevMessageRef.current = message;
        }
    }, [message, language, hasInteracted, voices]);
    
    useEffect(() => {
        return () => {
            if (speechSynthesis.speaking) {
                speechSynthesis.cancel();
            }
            setIsSelfSpeaking(false);
        };
    }, []);

    return (
        <motion.div 
            drag 
            dragMomentum={false}
            className={`fixed bottom-4 right-4 z-50 cursor-grab active:cursor-grabbing transition-transform duration-500 ease-in-out ${isVisible ? 'translate-x-0' : 'translate-x-[200%]'}`}
        >
            <div className="relative flex items-end justify-center pointer-events-none">
                {(message && showTooltip) && (
                    <div className="absolute bottom-full mb-3 right-0 w-64 bg-white dark:bg-slate-700 p-4 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-600 animate-fade-in-up origin-bottom-right pointer-events-auto">
                        <p className="text-sm font-medium text-slate-700 dark:text-slate-200 pr-8 leading-relaxed whitespace-pre-wrap">{message}</p>
                        <button
                            onClick={(e) => { e.stopPropagation(); handleSpeak(message); }}
                            className={`absolute top-4 right-4 p-1.5 rounded-full transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-700 ${
                                isSelfSpeaking 
                                ? 'bg-red-500 text-white hover:bg-red-600 focus:ring-red-500 shadow-md scale-110' 
                                : 'bg-slate-100 dark:bg-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-500 focus:ring-orange-500'
                            }`}
                            aria-label={isSelfSpeaking ? "Stop speaking" : "Read message aloud"}
                        >
                            <SpeakerIcon className="w-4 h-4" />
                        </button>
                        <div className="absolute right-6 -bottom-2 w-0 h-0 border-x-8 border-x-transparent border-t-8 border-t-white dark:border-t-slate-700"></div>
                    </div>
                )}
                
        <button 
            onClick={(e) => {
                e.stopPropagation();
                if (message) {
                    handleSpeak(message);
                    setShowTooltip(true);
                }
            }} 
            className={`w-16 h-16 sm:w-20 sm:h-20 focus:outline-none focus:ring-4 focus:ring-orange-500 rounded-full pointer-events-auto transition-transform ${isGlobalSpeaking ? 'animate-bob' : 'hover:scale-105'}`} 
            aria-label="Ask Aria for help"
        >
                    <svg viewBox="0 0 100 100" className="drop-shadow-lg overflow-visible">
                        {/* Back Hair */}
                        <path d="M 15 50 C 15 10, 85 10, 85 50 C 85 80, 95 85, 75 85 C 65 85, 60 80, 60 80 C 50 85, 40 85, 30 80 C 30 80, 25 85, 15 85 C -5 85, 15 80, 15 50 Z" fill="#8C421B" stroke="#4A2012" strokeWidth="4" strokeLinejoin="round" />

                        {/* Head Group for Tilt/Nod */}
                        <g style={{ transformOrigin: '50px 92px', transform: isGlobalSpeaking ? 'rotate(var(--tilt, 0deg))' : 'none' }}>
                            {/* Ears */}
                            <path d="M 22 58 C 10 58, 10 72, 22 72" fill="#FFE4D6" stroke="#4A2012" strokeWidth="4" strokeLinejoin="round" />
                            <path d="M 78 58 C 90 58, 90 72, 78 72" fill="#FFE4D6" stroke="#4A2012" strokeWidth="4" strokeLinejoin="round" />
                            <circle cx="18" cy="65" r="3" fill="#FFAAA5" />
                            <circle cx="82" cy="65" r="3" fill="#FFAAA5" />

                            {/* Face - Rounder & Cuter */}
                            <path d="M 22 45 C 22 85, 35 92, 50 92 C 65 92, 78 85, 78 45 C 78 20, 65 15, 50 15 C 35 15, 22 20, 22 45 Z" fill="#FFE4D6" stroke="#4A2012" strokeWidth="4" strokeLinejoin="round" />

                            {/* Front Hair / Bangs */}
                            <path d="M 50 15 C 25 15, 18 35, 18 55 L 18 65 C 22 70, 26 70, 28 65 L 28 45 C 32 40, 40 30, 45 25 C 50 35, 60 40, 72 45 L 72 65 C 74 70, 78 70, 82 65 L 82 55 C 82 35, 75 15, 50 15 Z" fill="#8C421B" stroke="#4A2012" strokeWidth="4" strokeLinejoin="round" />

                            {/* Hair Highlights */}
                            <path d="M 24 35 C 26 30, 30 25, 32 25 C 30 30, 28 35, 24 35 Z" fill="#F4A460" />
                            <path d="M 76 35 C 74 30, 70 25, 68 25 C 70 30, 72 35, 76 35 Z" fill="#F4A460" />

                            {/* Eyebrows */}
                            <path d="M 25 42 Q 32 38 38 42" fill="none" stroke="#4A2012" strokeWidth="3" strokeLinecap="round" />
                            <path d="M 62 42 Q 68 38 75 42" fill="none" stroke="#4A2012" strokeWidth="3" strokeLinecap="round" />

                            {/* Left Eye - Cartoon style */}
                            <g className="aria-eyes eye-blink" style={{ transformOrigin: '35px 55px' }}>
                                <path d="M 28 55 C 28 45, 42 45, 42 55 C 42 65, 28 65, 28 55 Z" fill="#4A2012" />
                                <circle cx="37" cy="52" r="4" fill="#FFFFFF" />
                                <circle cx="33" cy="60" r="2" fill="#FFFFFF" />
                                <path d="M 26 52 C 32 45, 40 45, 45 50" fill="none" stroke="#4A2012" strokeWidth="3" strokeLinecap="round" />
                                <path d="M 26 52 L 23 49" stroke="#4A2012" strokeWidth="3" strokeLinecap="round" />
                                <path d="M 27 58 L 24 56" stroke="#4A2012" strokeWidth="3" strokeLinecap="round" />
                            </g>

                            {/* Right Eye - Cartoon style */}
                            <g className="aria-eyes eye-blink" style={{ transformOrigin: '65px 55px' }}>
                                <path d="M 58 55 C 58 45, 72 45, 72 55 C 72 65, 58 65, 58 55 Z" fill="#4A2012" />
                                <circle cx="63" cy="52" r="4" fill="#FFFFFF" />
                                <circle cx="67" cy="60" r="2" fill="#FFFFFF" />
                                <path d="M 55 50 C 60 45, 68 45, 74 52" fill="none" stroke="#4A2012" strokeWidth="3" strokeLinecap="round" />
                                <path d="M 74 52 L 77 49" stroke="#4A2012" strokeWidth="3" strokeLinecap="round" />
                                <path d="M 73 58 L 76 56" stroke="#4A2012" strokeWidth="3" strokeLinecap="round" />
                            </g>

                            {/* Cute Blush */}
                            <ellipse cx="28" cy="65" rx="5" ry="3" fill="#FFB6C1" opacity="0.7" />
                            <ellipse cx="72" cy="65" rx="5" ry="3" fill="#FFB6C1" opacity="0.7" />

                            {/* Cute Pointy/Button Nose */}
                            <path d="M 48 62 Q 50 65 52 62" fill="none" stroke="#4A2012" strokeWidth="2.5" strokeLinecap="round" />

                            {/* Mouth - animated when speaking */}
                            <g transform="translate(0, -2)">
                                <path d={mouthOpen ? "M 42 72 Q 50 82 58 72 Z" : "M 44 73 Q 50 78 56 73"} fill={mouthOpen ? "#8A2B3A" : "#D46A7E"} stroke={mouthOpen ? "#6B1D2C" : "#B34A60"} strokeWidth="2" strokeLinejoin="round" />
                                {mouthOpen && <path d="M 46 76 Q 50 74 54 76 Q 50 80 46 76" fill="#FF8DA1" />}
                            </g>
                        </g>
                    </svg>
                </button>
            </div>
        </motion.div>
    );
}

export default Character;